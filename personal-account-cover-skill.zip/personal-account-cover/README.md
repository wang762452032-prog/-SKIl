# Personal Account Cover Skill

A dedicated skill for cover-copy rewriting, visual direction, cover generation,
aspect-ratio adaptation, and evidence-based acceptance review.

## Structure

- `SKILL.md`: executable instructions and workflow.
- `references/cover-copywriting.md`: cover-copy rewrite method.
- `references/visual-language.md`: account visual identity and reference rules.
- `references/acceptance-checklist.md`: eight-point acceptance standard.
- `assets/README.md`: privacy-safe asset handling.

Supported ratios: 16:9, 9:16, 4:3, 3:4.

Personal portrait images and third-party reference screenshots are excluded
from this public package unless explicitly approved for public distribution.
