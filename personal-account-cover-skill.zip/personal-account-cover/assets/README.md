# Asset handling

This public skill repository intentionally does not include personal portrait
photos or third-party reference-account screenshots.

Add only portrait assets that the user has explicitly approved for public
distribution. Keep original source files separate from generated edits.

Suggested private/local structure:

- `assets/portrait-approved/`
- `assets/reference-notes/`

Do not commit private screenshots, personal photographs, account identifiers,
or unlicensed third-party creative assets to a public repository.
