---
name: personal-account-cover
description: >
  Personal-account short-video cover design and cover-copy rewriting skill.
  Use when the user asks to rewrite cover text, create or revise a video cover,
  design a thumbnail, adapt a cover to a platform ratio, or review a finished
  cover. Separates copy strategy from visual execution and requires inspection
  and acceptance before delivery.
---

# Personal Account Cover Skill

## 1. Mission

Create recognizable, topic-specific covers for the user's personal content account.
The cover must communicate the subject, the reason to watch, and one central
message at thumbnail size. It must match the actual video and must not invent
facts, outcomes, identities, statistics, credentials, or urgency.

This is a dedicated cover skill. It can cooperate with a broader publishing
workflow, but it does not replace script writing, platform publishing, or
account analytics.

## 2. Trigger conditions

Activate when the user asks to:
- rewrite, shorten, strengthen, or select cover copy;
- design, generate, revise, or evaluate a cover/thumbnail;
- adapt one cover concept to 16:9, 9:16, 4:3, or 3:4;
- build a consistent visual series for the account;
- compare cover directions or review finished images.

If the user asks only for copy, do not generate an image. If the user asks for
an image/cover, create the image after the copy and visual direction are clear.

## 3. Required reasoning before execution

Internally identify:
1. Topic and content type: knowledge, opinion, story, case, tutorial, policy,
   review, list, or vlog.
2. Intended viewer: who should recognize that this is relevant to them?
3. Main publishing objective: reach, search, trust, follows, interaction, or
   conversion. Choose one primary objective.
4. Single core message: the one fact, question, conflict, result, or judgment
   the viewer should remember.
5. Viewing promise: what answer or useful judgment will the video provide?
6. Evidence and risk: what is supported by the supplied script/material, what
   is uncertain, and what must not be implied?
7. Visual opportunity: what can the person, setting, prop, or graphic explain?

Use information already provided. Ask only for a missing detail that materially
changes factual accuracy or the design. Otherwise make a conservative choice
and proceed.

## 4. Cover-copy rewriting protocol

### 4.1 Extract before rewriting
Read the complete script or content summary. Extract:
- actual subject;
- strongest supported fact;
- central contradiction or question;
- audience pain, decision, benefit, or cost;
- conclusion the video can genuinely deliver.

Do not select a provocative phrase merely because it sounds clickable.

### 4.2 Copy hierarchy
Build the cover around:
- Main headline: one dominant message, normally the shortest and clearest
  expression of the core question, result, or conflict.
- Supporting line: optional; clarifies context, audience, or consequence.
- Small label: optional series/category tag, only if it helps recognition.

Do not put the full video title or full sentence on the cover. Do not stack
multiple unrelated promises.

### 4.3 Candidate generation
Generate up to three genuinely different directions, not three cosmetic
rewrites:
1. Direct question or problem.
2. Contrast, misconception, or conflict.
3. Concrete result, decision, or value.

For each candidate, state:
- cover copy;
- copy angle;
- what the viewer expects to learn;
- what in the supplied content fulfils that expectation;
- risk of misunderstanding or overclaiming.

Recommend one direction with reasons. Do not use quantity as a substitute for
quality.

### 4.4 Copy quality checks
- Understandable to a new viewer without specialist context.
- One primary message.
- Short enough to read quickly on a phone.
- Strong verbs and concrete nouns; remove filler and abstract wording.
- The headline and visual reinforce each other instead of repeating the same
  information mechanically.
- No unsupported numbers, superlatives, guarantees, or false urgency.
- Acronyms such as FDE, AI, or technical terms need context when the intended
  audience may not understand them.
- Promise must be fulfilled by the video.

## 5. Visual identity

### 5.1 Established visual preferences
The user's previously confirmed preferences include:
- bold brush/paint-like lettering;
- thick, high-contrast outlines and slight type rotation where appropriate;
- vivid blue, orange-red, and yellow accents;
- monochrome/black-and-white subject portraits against graphic color fields;
- a clear visual hook and comfortable composition;
- strong relationship between subject, scene, prop, and message.

These are account-level preferences, not mandatory decoration. Use them only
when they support the specific topic.

### 5.2 Reference learning
Learn from the three reference directions without mechanically copying them:
- Direction A: energetic, brush-style display type, thick outline, vivid
  contrast, strong portrait presence.
- Direction B: topic-led layouts that use scene, evidence, and context to
  explain the subject.
- Direction C: cleaner composition, concise hook, readable hierarchy, and
  close integration of person, setting, and content.

Do not copy another creator's exact layout, unique visual identity, wording,
watermarks, or recognizable design assets. Do not change the approved account
style just because a new reference appears. Explain any proposed style change
with a concrete comparison.

### 5.3 Person and reference-image handling
- Use only the user's supplied or explicitly approved portrait assets.
- Preserve recognizable facial features and identity when editing a supplied
  portrait. Do not silently substitute a different person.
- Do not invent a new personal reference portrait.
- Keep the original source image separate from generated derivatives.
- Third-party account screenshots are for visual analysis only. Do not publish
  them as assets or reproduce identifying marks.
- If the approved portrait asset is unavailable in the current task, ask the
  user to provide it or proceed with a non-identifiable layout.

### 5.4 Composition
- Establish one dominant focal point.
- Maintain a clear reading order: headline, supporting line, subject/scene,
  then optional label.
- Give text safe margins and sufficient contrast.
- Keep the face, hands, and essential props clear of text collisions.
- Use background, props, and scene details only when they add information.
- Avoid decorative clutter, repeated arrows, redundant icons, and excessive
  glow, bevel, or shadow effects.
- Do not make the subject so small that the account loses human recognition.
- Do not let text cover eyes, mouth, hands, or the key object unless the
  concept explicitly requires it.

## 6. Aspect-ratio adaptation

Supported deliverables:
- 9:16, default 1080 × 1920;
- 3:4, default 1080 × 1440;
- 16:9, default 1920 × 1080;
- 4:3, default 1440 × 1080.

Each ratio must be composed independently. Do not simply crop or stretch one
master image. Reposition the subject, headline, supporting line, and props for
each canvas. Preserve the same copy hierarchy and visual identity while
adapting layout to the available space.

If the user requests one ratio, deliver only that ratio. If the user requests
all four, export all four and verify each file's dimensions.

## 7. Production workflow

1. Confirm objective, audience, core message, reference benefits, factual
   boundaries, and required ratios.
2. Rewrite and select cover copy before image production.
3. Define visual hierarchy, subject treatment, scene, palette, and typography.
4. Generate or edit the cover using the approved source portrait when supplied.
5. Inspect the actual generated image, not only the prompt or a description.
6. Correct text errors, malformed hands, facial inconsistencies, visual
   collisions, contrast, margins, and ratio problems.
7. Inspect a small thumbnail. For 9:16, inspect at least 180 × 320 pixels.
8. Verify exact image dimensions and file readability.
9. If a core defect remains, revise and inspect again. Never call a draft final
   before acceptance.
10. Deliver the image(s), chosen copy, rationale, and acceptance checklist.

## 8. Eight-point acceptance standard

Every finished cover must be checked against:

1. Topic: can an unfamiliar viewer identify what the content is about?
2. Viewing reason: is there a clear answer, result, or judgment to gain?
3. Reading hierarchy: is the first reading point obvious, with supporting
   information clearly secondary?
4. Visual expression: does each major person, scene, or prop contribute?
5. Series identity: does it still look like this account?
6. Single-post distinction: can this episode be distinguished from adjacent
   posts in a grid? If no grid sample is available, mark unverified.
7. Content fulfilment: can the actual video deliver every promise made by the
   copy and imagery?
8. Recommendation basis: can the design choice be justified by specific
   strengths, trade-offs, and intended use?

Use explicit statuses: PASS, PARTIAL, FAIL, or NOT VERIFIED. Give evidence for
each status. Do not claim improved CTR, retention, or conversion without
account-level data.

## 9. Delivery format

For copy-only tasks:
- Core message
- Recommended cover copy
- Up to two meaningfully different alternatives
- Reason for recommendation
- Content/factual risk, if any

For cover-design tasks:
- Final image(s) and dimensions
- Selected cover copy
- Short design rationale
- Eight-point acceptance results
- Known limitations or items not verified

For revisions, state exactly what changed and why. Preserve previously
approved elements unless the user asks to change them or there is a material
defect.

## 10. Failure protocol

Stop and flag the issue when:
- the supplied content does not support the proposed headline;
- the core topic cannot be understood from available material;
- the user's approved portrait is missing but identity fidelity is required;
- text rendering or image defects remain unresolved;
- the requested ratio or export format cannot be verified;
- a third-party reference would need to be copied too closely.

Offer the smallest practical correction. Never hide uncertainty or claim a
file was saved, synced, uploaded, or delivered unless that operation succeeded.
