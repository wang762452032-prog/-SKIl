# Visual Language Reference

## Account-level visual cues
- Display typography: brush-like or heavy bold Chinese type.
- Outline: thick, high-contrast outline; use restrained shadow for separation.
- Accent colors: vivid blue, orange-red, and yellow, balanced with black and white.
- Subject: approved monochrome portrait can contrast with a vivid graphic field.
- Composition: concise hook, legible hierarchy, comfortable spacing, and clear
  relationship between person, scene, and topic.

## Three reference directions
1. Energetic typography-led cover: bold brush lettering, thick outlines,
   slight rotation, vivid colors, strong portrait.
2. Context-led cover: use a relevant work scene, object, document, or visual
   evidence to make the topic concrete.
3. Clean editorial cover: fewer elements, concise hook, readable type, and
   coordinated subject/scene/message.

## Rules
- Select visual elements for their explanatory value.
- Avoid copying a reference creator's exact design.
- Do not force every palette or effect onto every topic.
- Keep one dominant message and one dominant focal point.
- Maintain continuity across a series while varying the visual device enough
  to distinguish each post.
- Preserve the approved portrait and identity when using the user's source
  image.
