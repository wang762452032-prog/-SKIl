# Cover Copywriting Reference

## The cover's job
A cover is a compressed promise. It must tell the right viewer:
1. what the subject is;
2. why it matters;
3. what useful answer, result, or judgment is inside.

## Rewrite sequence
1. Reduce the script to one sentence.
2. Identify the strongest supported tension, question, result, or cost.
3. Translate jargon into audience language where necessary.
4. Write a short main line.
5. Add a secondary line only when context is missing.
6. Check that the video actually delivers the promise.

## Three useful directions
- Direct question: make the real question explicit.
- Contrast: expose a meaningful gap between assumption and reality.
- Result/value: show the useful conclusion or decision framework.

## Reject
- vague hype such as "爆了", "封神", "颠覆认知" without evidence;
- unsupported statistics or guarantees;
- multiple unrelated ideas on one cover;
- a headline that merely repeats the spoken first sentence;
- jargon that the intended viewer cannot decode;
- a promise that the body of the video does not fulfil.

## Review table
| Test | Question |
|---|---|
| Relevance | Does the intended viewer recognize themselves or their problem? |
| Clarity | Can the message be understood in one quick glance? |
| Specificity | Is there a concrete question, conflict, result, or decision? |
| Promise | What does the viewer expect to receive? |
| Proof | Where does the video fulfil that expectation? |
| Brevity | Can any word be removed without losing meaning? |
