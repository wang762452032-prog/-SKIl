# Eight-point Cover Acceptance Checklist

Mark each item PASS, PARTIAL, FAIL, or NOT VERIFIED and cite the visual
evidence from the actual output.

| Item | Acceptance question | Evidence |
|---|---|---|
| Topic | Can an unfamiliar viewer identify the subject? | The first-glance reading |
| Viewing reason | Is there a clear answer, result, or judgment to gain? | Headline and content promise |
| Reading hierarchy | Is the reading order obvious? | Size, weight, contrast, spacing |
| Visual expression | Do person, scene, and props contribute? | Function of each major element |
| Series identity | Does the cover belong to the account? | Approved palette, typography, portrait, composition |
| Single-post distinction | Is this post distinguishable in a grid? | Actual grid comparison, or mark unverified |
| Content fulfilment | Does the video deliver the promise? | Script/voiceover evidence |
| Recommendation basis | Is the recommendation supported by specific trade-offs? | Strengths, costs, use case, limitations |

## Technical inspection
- Verify exact dimensions and aspect ratio.
- Inspect at full resolution.
- Inspect a thumbnail. For 9:16, use at least 180 × 320 px.
- Check spelling, punctuation, text rendering, safe margins, contrast, face,
  hands, and prop integrity.
- Confirm the output file opens and is not corrupted.

Never infer CTR or retention improvement from design taste alone.
